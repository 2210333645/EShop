package com.huawei.eshop.goods.service;

import com.huawei.eshop.goods.entity.Goods;

import java.util.List;

public interface GoodsService {



    public List<Goods> getDoodsList() throws Exception;



    public Goods getGoodsDetail();


}
