package com.huawei.eshop.goods.dao;

import com.huawei.eshop.goods.entity.Goods;

import java.util.List;

public interface GoodsDao {

    List<Goods> GOODS_LIST() throws Exception;

}
