package com.huawei.eshop.common.dao;
/*
1.调用IDateAccess层查询数据
2.返回结果
 */
public interface BaseDAO {
}
