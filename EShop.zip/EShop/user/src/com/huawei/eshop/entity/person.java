package com.huawei.eshop.entity;

import com.huawei.eshop.common.entity.Entity;

public class person extends Entity {
}
