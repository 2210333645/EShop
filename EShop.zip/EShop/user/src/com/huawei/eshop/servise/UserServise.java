package com.huawei.eshop.servise;

import com.huawei.eshop.entity.User;

public interface UserServise {
    User login (User user) throws Exception ;
}
